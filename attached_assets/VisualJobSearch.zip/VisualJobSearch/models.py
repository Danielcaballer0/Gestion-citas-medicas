from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from datetime import datetime
import uuid
from app import db
from sqlalchemy import String, Integer, Float, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

# User model for authentication
class User(db.Model, UserMixin):
    __tablename__ = 'users'
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(120), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=True)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[str] = mapped_column(String(20), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now())
    
    # Discriminator column for inheritance
    type: Mapped[str] = mapped_column(String(20))
    
    __mapper_args__ = {
        "polymorphic_on": type,
        "polymorphic_identity": "user"
    }
    
    def __init__(self, email, password, role, name=None):
        self.email = email
        self.password_hash = generate_password_hash(password)
        self.role = role
        self.name = name
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    @classmethod
    def get_by_email(cls, email):
        return cls.query.filter_by(email=email).first()

# Patient model
class Patient(User):
    __tablename__ = 'patients'
    
    id: Mapped[int] = mapped_column(ForeignKey("users.id"), primary_key=True)
    phone: Mapped[str] = mapped_column(String(20), nullable=True)
    date_of_birth: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    address: Mapped[str] = mapped_column(Text, nullable=True)
    
    # Relationships
    appointments = relationship("Appointment", back_populates="patient", foreign_keys="Appointment.patient_id")
    
    __mapper_args__ = {
        "polymorphic_identity": "patient",
    }
    
    def __init__(self, email, password, name, phone=None, date_of_birth=None, address=None):
        super().__init__(email, password, 'patient', name)
        self.phone = phone
        self.date_of_birth = date_of_birth
        self.address = address
    
    def get_appointments(self):
        return self.appointments
    
    @classmethod
    def create(cls, email, password, name, phone=None, date_of_birth=None, address=None):
        patient = cls(email, password, name, phone, date_of_birth, address)
        db.session.add(patient)
        db.session.commit()
        return patient

# Specialty model
class Specialty(db.Model):
    __tablename__ = 'specialties'
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=True)
    
    # Relationships
    doctors = relationship("Doctor", back_populates="specialty")
    
    def __init__(self, name, description=None):
        self.name = name
        self.description = description
    
    @classmethod
    def create(cls, name, description=None):
        specialty = cls(name, description)
        db.session.add(specialty)
        db.session.commit()
        return specialty
    
    @classmethod
    def get_all(cls):
        return cls.query.all()

# Available slot model
class AvailableSlot(db.Model):
    __tablename__ = 'available_slots'
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    doctor_id: Mapped[int] = mapped_column(Integer, ForeignKey('doctors.id'))
    slot_datetime: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    
    # Relationships
    doctor = relationship("Doctor", back_populates="available_slots")
    
    def __init__(self, doctor_id, slot_datetime):
        self.doctor_id = doctor_id
        self.slot_datetime = slot_datetime

# Doctor model
class Doctor(User):
    __tablename__ = 'doctors'
    
    id: Mapped[int] = mapped_column(ForeignKey("users.id"), primary_key=True)
    specialty_id: Mapped[int] = mapped_column(Integer, ForeignKey('specialties.id'), nullable=True)
    bio: Mapped[str] = mapped_column(Text, nullable=True)
    phone: Mapped[str] = mapped_column(String(20), nullable=True)
    
    # Relationships
    specialty = relationship("Specialty", back_populates="doctors")
    available_slots = relationship("AvailableSlot", back_populates="doctor", cascade="all, delete-orphan")
    appointments = relationship("Appointment", back_populates="doctor", foreign_keys="Appointment.doctor_id")
    
    __mapper_args__ = {
        "polymorphic_identity": "doctor",
    }
    
    def __init__(self, email, password, name, specialty_id=None, bio=None, phone=None):
        super().__init__(email, password, 'doctor', name)
        self.specialty_id = specialty_id
        self.bio = bio
        self.phone = phone
    
    def get_specialty(self):
        return self.specialty
    
    def add_available_slot(self, slot_datetime):
        new_slot = AvailableSlot(self.id, slot_datetime)
        db.session.add(new_slot)
        db.session.commit()
    
    def remove_available_slot(self, slot_datetime):
        slot = AvailableSlot.query.filter_by(doctor_id=self.id, slot_datetime=slot_datetime).first()
        if slot:
            db.session.delete(slot)
            db.session.commit()
    
    def get_appointments(self):
        return self.appointments
    
    @classmethod
    def create(cls, email, password, name, specialty_id=None, bio=None, phone=None):
        doctor = cls(email, password, name, specialty_id, bio, phone)
        db.session.add(doctor)
        db.session.commit()
        return doctor
    
    @classmethod
    def get_all(cls):
        return cls.query.all()
    
    @classmethod
    def get_by_specialty(cls, specialty_id):
        return cls.query.filter_by(specialty_id=specialty_id).all()

# Admin model
class Admin(User):
    __tablename__ = 'admins'
    
    id: Mapped[int] = mapped_column(ForeignKey("users.id"), primary_key=True)
    
    __mapper_args__ = {
        "polymorphic_identity": "admin",
    }
    
    def __init__(self, email, password, name):
        super().__init__(email, password, 'admin', name)
    
    @classmethod
    def create(cls, email, password, name):
        admin = cls(email, password, name)
        db.session.add(admin)
        db.session.commit()
        return admin

# Appointment model
class Appointment(db.Model):
    __tablename__ = 'appointments'
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    patient_id: Mapped[int] = mapped_column(Integer, ForeignKey('patients.id'))
    doctor_id: Mapped[int] = mapped_column(Integer, ForeignKey('doctors.id'))
    datetime: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    status: Mapped[str] = mapped_column(String(20), default='scheduled')
    notes: Mapped[str] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now())
    
    # Relationships
    patient = relationship("Patient", back_populates="appointments", foreign_keys=[patient_id])
    doctor = relationship("Doctor", back_populates="appointments", foreign_keys=[doctor_id])
    
    def __init__(self, id, patient_id, doctor_id, datetime, status='scheduled', notes=None):
        self.id = id
        self.patient_id = patient_id
        self.doctor_id = doctor_id
        self.datetime = datetime
        self.status = status
        self.notes = notes
    
    def get_patient(self):
        return self.patient
    
    def get_doctor(self):
        return self.doctor
    
    def cancel(self):
        self.status = 'canceled'
        doctor = self.get_doctor()
        if doctor:
            doctor.add_available_slot(self.datetime)
        db.session.commit()
    
    def complete(self):
        self.status = 'completed'
        db.session.commit()
    
    @classmethod
    def create(cls, patient_id, doctor_id, appointment_datetime, notes=None):
        appointment_id = str(uuid.uuid4())
        appointment = cls(appointment_id, patient_id, doctor_id, appointment_datetime, 'scheduled', notes)
        
        # Remove slot from available slots
        doctor = Doctor.query.get(doctor_id)
        if doctor:
            doctor.remove_available_slot(appointment_datetime)
        
        db.session.add(appointment)
        db.session.commit()
        return appointment
    
    @classmethod
    def get_by_patient(cls, patient_id):
        return cls.query.filter_by(patient_id=patient_id).all()
    
    @classmethod
    def get_by_doctor(cls, doctor_id):
        return cls.query.filter_by(doctor_id=doctor_id).all()

# Initialize data function
def initialize_data():
    # Check if data already exists
    if Specialty.query.count() == 0:
        # Create specialties
        specialties = [
            "General Medicine",
            "Cardiology",
            "Dermatology",
            "Orthopedics",
            "Neurology",
            "Pediatrics",
            "Obstetrics & Gynecology",
            "Ophthalmology"
        ]
        
        for specialty_name in specialties:
            Specialty.create(specialty_name)
        
        # Create admin account if it doesn't exist
        if not User.get_by_email("admin@medicalapp.com"):
            Admin.create("admin@medicalapp.com", "admin123", "System Administrator")
