from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField, TextAreaField, DateField, EmailField, TelField, HiddenField
from wtforms.validators import DataRequired, Email, EqualTo, Length, Optional

class LoginForm(FlaskForm):
    email = EmailField('Correo Electrónico', validators=[DataRequired(), Email()])
    password = PasswordField('Contraseña', validators=[DataRequired()])
    submit = SubmitField('Iniciar Sesión')

class PatientRegistrationForm(FlaskForm):
    name = StringField('Nombre Completo', validators=[DataRequired()])
    email = EmailField('Correo Electrónico', validators=[DataRequired(), Email()])
    password = PasswordField('Contraseña', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirmar Contraseña', validators=[DataRequired(), EqualTo('password')])
    phone = TelField('Número de Teléfono', validators=[Optional()])
    date_of_birth = DateField('Fecha de Nacimiento', validators=[Optional()])
    address = TextAreaField('Dirección', validators=[Optional()])
    submit = SubmitField('Registrarse')

class DoctorRegistrationForm(FlaskForm):
    name = StringField('Nombre Completo', validators=[DataRequired()])
    email = EmailField('Correo Electrónico', validators=[DataRequired(), Email()])
    password = PasswordField('Contraseña', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirmar Contraseña', validators=[DataRequired(), EqualTo('password')])
    specialty = SelectField('Especialidad', validators=[DataRequired()], coerce=int)
    phone = TelField('Número de Teléfono', validators=[Optional()])
    bio = TextAreaField('Biografía Profesional', validators=[Optional()])
    submit = SubmitField('Registrarse')

class AppointmentForm(FlaskForm):
    doctor_id = HiddenField(validators=[DataRequired()])
    appointment_date = DateField('Fecha', validators=[DataRequired()])
    appointment_time = SelectField('Hora', validators=[DataRequired()])
    notes = TextAreaField('Motivo de la Visita', validators=[Optional()])
    submit = SubmitField('Programar Cita')

class ProfileUpdateForm(FlaskForm):
    name = StringField('Nombre Completo', validators=[DataRequired()])
    phone = TelField('Número de Teléfono', validators=[Optional()])
    address = TextAreaField('Dirección', validators=[Optional()])
    submit = SubmitField('Actualizar Perfil')

class DoctorProfileUpdateForm(FlaskForm):
    name = StringField('Nombre Completo', validators=[DataRequired()])
    specialty = SelectField('Especialidad', validators=[DataRequired()], coerce=int)
    phone = TelField('Número de Teléfono', validators=[Optional()])
    bio = TextAreaField('Biografía Profesional', validators=[Optional()])
    submit = SubmitField('Actualizar Perfil')

class SearchForm(FlaskForm):
    specialty = SelectField('Filtrar por Especialidad', coerce=int)
    submit = SubmitField('Buscar')
