// Calendar functionality for appointment scheduling

document.addEventListener('DOMContentLoaded', function() {
  // Initialize FullCalendar if the container exists
  const calendarEl = document.getElementById('appointment-calendar');
  if (calendarEl) {
    initializeCalendar(calendarEl);
  }

  // Initialize mini calendar for dashboard if it exists
  const miniCalendarEl = document.getElementById('mini-calendar');
  if (miniCalendarEl) {
    initializeMiniCalendar(miniCalendarEl);
  }
});

function initializeCalendar(calendarEl) {
  const doctorId = calendarEl.dataset.doctorId;
  
  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,timeGridWeek,timeGridDay'
    },
    selectable: true,
    selectMirror: true,
    navLinks: true,
    dayMaxEvents: true,
    height: 'auto',
    themeSystem: 'bootstrap5',
    
    // Allow date selection to schedule appointments
    dateClick: function(info) {
      // Update the appointment form date field
      const dateInput = document.getElementById('appointment_date');
      if (dateInput) {
        dateInput.value = info.dateStr;
        
        // Trigger change event to load available times
        const event = new Event('change');
        dateInput.dispatchEvent(event);
      }
      
      // Scroll to the appointment form
      const appointmentForm = document.getElementById('appointment-form');
      if (appointmentForm) {
        appointmentForm.scrollIntoView({ behavior: 'smooth' });
      }
    },
    
    // Load events (appointments) if authenticated and viewing own calendar
    events: function(info, successCallback, failureCallback) {
      // In a real implementation, this would fetch the doctor's availability
      // For demo purposes, we'll generate some sample availability
      
      const events = [];
      const currentDate = new Date();
      
      // Generate events for the next 30 days
      for (let i = 0; i < 30; i++) {
        const date = new Date();
        date.setDate(currentDate.getDate() + i);
        
        // Skip weekends
        if (date.getDay() === 0 || date.getDay() === 6) {
          continue;
        }
        
        // Generate time slots from 9 AM to 4 PM
        for (let hour = 9; hour < 17; hour++) {
          // Random availability
          const isAvailable = Math.random() > 0.3; // 70% chance of availability
          
          if (isAvailable) {
            const startTime = new Date(date);
            startTime.setHours(hour, 0, 0);
            
            const endTime = new Date(date);
            endTime.setHours(hour + 1, 0, 0);
            
            events.push({
              title: 'Available',
              start: startTime,
              end: endTime,
              classNames: ['available'],
              display: 'block'
            });
          }
        }
      }
      
      successCallback(events);
    }
  });
  
  calendar.render();
  
  // Expose the calendar object to global scope for potential external access
  window.appointmentCalendar = calendar;
}

function initializeMiniCalendar(calendarEl) {
  // Get appointments data from data attribute
  let appointments = [];
  try {
    appointments = JSON.parse(calendarEl.dataset.appointments || '[]');
  } catch (e) {
    console.error('Error parsing appointments data:', e);
  }
  
  // Map appointments to FullCalendar event format
  const events = appointments.map(apt => {
    return {
      title: apt.title || 'Appointment',
      start: apt.datetime,
      className: `status-${apt.status}`,
      url: `/appointments/${apt.id}/confirmation`
    };
  });
  
  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',
    headerToolbar: {
      left: 'prev,next',
      center: 'title',
      right: 'today'
    },
    height: 'auto',
    events: events,
    themeSystem: 'bootstrap5',
    dayMaxEvents: true
  });
  
  calendar.render();
}
