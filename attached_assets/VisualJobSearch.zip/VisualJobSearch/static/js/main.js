// Main JavaScript file for the medical appointment system

document.addEventListener('DOMContentLoaded', function() {
  // Enable Bootstrap tooltips
  const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
  if (tooltips.length > 0) {
    tooltips.forEach(tooltip => {
      new bootstrap.Tooltip(tooltip);
    });
  }

  // Enable Bootstrap popovers
  const popovers = document.querySelectorAll('[data-bs-toggle="popover"]');
  if (popovers.length > 0) {
    popovers.forEach(popover => {
      new bootstrap.Popover(popover);
    });
  }

  // Time slot selection functionality
  const timeSlots = document.querySelectorAll('.time-slot:not(.unavailable)');
  if (timeSlots.length > 0) {
    timeSlots.forEach(slot => {
      slot.addEventListener('click', function() {
        // Clear previously selected
        document.querySelectorAll('.time-slot').forEach(s => {
          s.classList.remove('selected');
        });
        
        // Select this slot
        slot.classList.add('selected');
        
        // Update hidden input
        const timeInput = document.getElementById('appointment_time');
        if (timeInput) {
          timeInput.value = slot.dataset.time;
        }
      });
    });
  }

  // Appointment date change handler
  const appointmentDateInput = document.getElementById('appointment_date');
  if (appointmentDateInput) {
    appointmentDateInput.addEventListener('change', function() {
      const date = this.value;
      const doctorId = document.getElementById('doctor_id').value;
      
      // Fetch available slots for this date
      fetch(`/api/doctor/${doctorId}/availability?date=${date}`)
        .then(response => response.json())
        .then(data => {
          const timeSlotsContainer = document.getElementById('time_slots_container');
          if (timeSlotsContainer) {
            // Clear existing slots
            timeSlotsContainer.innerHTML = '';
            
            if (data.available_slots && data.available_slots.length > 0) {
              // Create time slots
              data.available_slots.forEach(slot => {
                // Convert 24h format to 12h format for display
                const time = new Date(`2000-01-01T${slot}`);
                const displayTime = time.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                
                const slotElement = document.createElement('div');
                slotElement.className = 'time-slot';
                slotElement.dataset.time = slot;
                slotElement.textContent = displayTime;
                slotElement.addEventListener('click', function() {
                  document.querySelectorAll('.time-slot').forEach(s => {
                    s.classList.remove('selected');
                  });
                  slotElement.classList.add('selected');
                  document.getElementById('appointment_time').value = slot;
                });
                
                timeSlotsContainer.appendChild(slotElement);
              });
            } else {
              timeSlotsContainer.innerHTML = '<p class="text-muted">No available time slots for this date.</p>';
            }
          }
        })
        .catch(error => {
          console.error('Error fetching availability:', error);
        });
    });
  }

  // Search form specialty filter change handler
  const specialtySelect = document.getElementById('specialty');
  if (specialtySelect) {
    specialtySelect.addEventListener('change', function() {
      document.getElementById('search_form').submit();
    });
  }

  // Appointment cancellation confirmation
  const cancelButtons = document.querySelectorAll('.cancel-appointment');
  if (cancelButtons.length > 0) {
    cancelButtons.forEach(button => {
      button.addEventListener('click', function(e) {
        if (!confirm('Are you sure you want to cancel this appointment?')) {
          e.preventDefault();
        }
      });
    });
  }

  // Appointment completion confirmation
  const completeButtons = document.querySelectorAll('.complete-appointment');
  if (completeButtons.length > 0) {
    completeButtons.forEach(button => {
      button.addEventListener('click', function(e) {
        if (!confirm('Are you sure you want to mark this appointment as completed?')) {
          e.preventDefault();
        }
      });
    });
  }
});
