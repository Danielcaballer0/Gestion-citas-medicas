from flask import render_template, redirect, url_for, flash, request, jsonify, session
from app import app, db
from forms import (
    LoginForm, PatientRegistrationForm, DoctorRegistrationForm, AppointmentForm,
    ProfileUpdateForm, DoctorProfileUpdateForm, SearchForm
)
from models import User, Patient, Doctor, Admin, Appointment, Specialty, AvailableSlot
from flask_login import login_user, logout_user, login_required, current_user
from datetime import datetime, timedelta
from utils import send_appointment_notification
from sqlalchemy import func
import uuid

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    form = PatientRegistrationForm()
    if form.validate_on_submit():
        if User.query.filter_by(email=form.email.data).first():
            flash('Este correo ya está registrado. Por favor usa un correo diferente.', 'danger')
            return render_template('register.html', form=form)
        
        patient = Patient(
            email=form.email.data,
            password=form.password.data,
            name=form.name.data,
            phone=form.phone.data, 
            date_of_birth=form.date_of_birth.data,
            address=form.address.data
        )
        db.session.add(patient)
        db.session.commit()
        
        flash('¡Registro exitoso! Ahora puedes iniciar sesión.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html', form=form)

@app.route('/register/doctor', methods=['GET', 'POST'])
def register_doctor():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    form = DoctorRegistrationForm()
    form.specialty.choices = [(s.id, s.name) for s in Specialty.query.all()]
    
    if form.validate_on_submit():
        if User.query.filter_by(email=form.email.data).first():
            flash('Este correo ya está registrado. Por favor usa un correo diferente.', 'danger')
            return render_template('register.html', form=form, is_doctor=True)
        
        doctor = Doctor(
            email=form.email.data,
            password=form.password.data,
            name=form.name.data,
            specialty_id=form.specialty.data,
            bio=form.bio.data,
            phone=form.phone.data
        )
        db.session.add(doctor)
        db.session.commit()
        
        flash('¡Registro exitoso! Ahora puedes iniciar sesión.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html', form=form, is_doctor=True)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            next_page = request.args.get('next')
            flash('¡Inicio de sesión exitoso!', 'success')
            return redirect(next_page or url_for('dashboard'))
        else:
            flash('Inicio de sesión fallido. Por favor verifica tu correo y contraseña.', 'danger')
    
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Has cerrado sesión correctamente.', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    now = datetime.now()
    
    if current_user.role == 'patient':
        upcoming_appointments = Appointment.query.filter_by(
            patient_id=current_user.id, 
            status='scheduled'
        ).filter(Appointment.datetime > now).all()
        
        past_appointments = Appointment.query.filter_by(
            patient_id=current_user.id
        ).filter(
            (Appointment.status.in_(['completed', 'canceled'])) | 
            (Appointment.datetime <= now)
        ).all()
        
        return render_template('dashboard_patient.html', 
                              upcoming_appointments=upcoming_appointments, 
                              past_appointments=past_appointments,
                              now=now)
    
    elif current_user.role == 'doctor':
        today = now.date()
        
        today_appointments = Appointment.query.filter_by(
            doctor_id=current_user.id, 
            status='scheduled'
        ).filter(
            func.date(Appointment.datetime) == today
        ).all()
        
        upcoming_appointments = Appointment.query.filter_by(
            doctor_id=current_user.id, 
            status='scheduled'
        ).filter(
            func.date(Appointment.datetime) > today
        ).all()
        
        return render_template('dashboard_doctor.html', 
                              today_appointments=today_appointments, 
                              upcoming_appointments=upcoming_appointments,
                              now=now)
    
    elif current_user.role == 'admin':
        patients = Patient.query.all()
        doctors = Doctor.query.all()
        appointments = Appointment.query.all()
        
        return render_template('dashboard_admin.html', 
                              patients=patients, 
                              doctors=doctors, 
                              appointments=appointments,
                              now=now)
    
    return redirect(url_for('index'))

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if current_user.role == 'patient':
        form = ProfileUpdateForm()
        if request.method == 'GET':
            form.name.data = current_user.name
            form.phone.data = current_user.phone
            form.address.data = current_user.address
        elif form.validate_on_submit():
            current_user.name = form.name.data
            current_user.phone = form.phone.data
            current_user.address = form.address.data
            db.session.commit()
            flash('¡Tu perfil ha sido actualizado!', 'success')
            return redirect(url_for('profile'))
    
    elif current_user.role == 'doctor':
        form = DoctorProfileUpdateForm()
        form.specialty.choices = [(s.id, s.name) for s in Specialty.query.all()]
        if request.method == 'GET':
            form.name.data = current_user.name
            form.specialty.data = current_user.specialty_id
            form.phone.data = current_user.phone
            form.bio.data = current_user.bio
        elif form.validate_on_submit():
            current_user.name = form.name.data
            current_user.specialty_id = form.specialty.data
            current_user.phone = form.phone.data
            current_user.bio = form.bio.data
            db.session.commit()
            flash('¡Tu perfil ha sido actualizado!', 'success')
            return redirect(url_for('profile'))
    
    else:
        form = None
    
    now = datetime.now()
    return render_template('profile.html', form=form, now=now)

@app.route('/doctors')
def doctors():
    search_form = SearchForm()
    search_form.specialty.choices = [(0, 'Todas las Especialidades')] + [(s.id, s.name) for s in Specialty.query.all()]
    
    specialty_id = request.args.get('specialty', type=int, default=0)
    if specialty_id:
        doctors_list = Doctor.query.filter_by(specialty_id=specialty_id).all()
    else:
        doctors_list = Doctor.query.all()
    
    return render_template('doctors.html', doctors=doctors_list, specialties=Specialty.query.all(), form=search_form)

@app.route('/doctors/<int:doctor_id>')
def doctor_profile(doctor_id):
    doctor = Doctor.query.get(doctor_id)
    if not doctor:
        flash('Médico no encontrado.', 'danger')
        return redirect(url_for('doctors'))
    
    return render_template('doctor_profile.html', doctor=doctor)

@app.route('/doctors/<int:doctor_id>/schedule', methods=['GET', 'POST'])
@login_required
def schedule_appointment(doctor_id):
    if current_user.role != 'patient':
        flash('Solo los pacientes pueden agendar citas.', 'warning')
        return redirect(url_for('doctor_profile', doctor_id=doctor_id))
    
    doctor = Doctor.query.get(doctor_id)
    if not doctor:
        flash('Médico no encontrado.', 'danger')
        return redirect(url_for('doctors'))
    
    form = AppointmentForm()
    form.doctor_id.data = doctor_id
    
    # Generate time slots for the next 30 days
    available_slots = []
    now = datetime.now()
    
    # Obtener slots existentes primero
    existing_slots = AvailableSlot.query.filter_by(doctor_id=doctor.id).all()
    existing_slot_times = [slot.slot_datetime for slot in existing_slots]
    
    for i in range(30):
        date = now.date() + timedelta(days=i)
        for hour in range(9, 17):  # 9 AM to 5 PM
            slot_time = datetime.combine(date, datetime.min.time()) + timedelta(hours=hour)
            if slot_time > now and slot_time in existing_slot_times:
                available_slots.append(slot_time)
    
    # Si no hay slots disponibles, agregar algunos para demostración
    if not available_slots:
        for i in range(30):
            date = now.date() + timedelta(days=i)
            for hour in range(9, 17):  # 9 AM to 5 PM
                slot_time = datetime.combine(date, datetime.min.time()) + timedelta(hours=hour)
                if slot_time > now:
                    # Crear un nuevo slot disponible
                    new_slot = AvailableSlot(doctor_id=doctor.id, slot_datetime=slot_time)
                    db.session.add(new_slot)
                    available_slots.append(slot_time)
        # Guardar todos los nuevos slots
        db.session.commit()
    
    # Create time choices for the form
    form.appointment_time.choices = [(time.strftime('%H:%M'), time.strftime('%I:%M %p')) for time in available_slots]
    
    if form.validate_on_submit():
        appointment_datetime = datetime.combine(
            form.appointment_date.data,
            datetime.strptime(form.appointment_time.data, '%H:%M').time()
        )
        
        # Verificar si el horario está disponible consultando la base de datos
        slot_available = AvailableSlot.query.filter_by(
            doctor_id=doctor_id,
            slot_datetime=appointment_datetime
        ).first()
        
        if not slot_available:
            flash('Este horario ya no está disponible. Por favor selecciona otro.', 'danger')
            return redirect(url_for('schedule_appointment', doctor_id=doctor_id))
        
        # Eliminar el horario de la lista de disponibles
        db.session.delete(slot_available)
        
        # Crear cita usando SQLAlchemy
        appointment = Appointment(
            id=str(uuid.uuid4()),
            patient_id=current_user.id,
            doctor_id=doctor_id,
            datetime=appointment_datetime,
            notes=form.notes.data,
            status='scheduled'
        )
        db.session.add(appointment)
        db.session.commit()
        
        # Send notification
        send_appointment_notification(appointment)
        
        flash('¡Cita agendada correctamente!', 'success')
        return redirect(url_for('appointment_confirmation', appointment_id=appointment.id))
    
    now = datetime.now()
    return render_template('schedule_appointment.html', form=form, doctor=doctor, available_slots=available_slots, now=now)

@app.route('/appointments/<appointment_id>/confirmation')
@login_required
def appointment_confirmation(appointment_id):
    appointment = Appointment.query.get(appointment_id)
    if not appointment:
        flash('Cita no encontrada.', 'danger')
        return redirect(url_for('dashboard'))
    
    # Check if user is allowed to view this appointment
    if current_user.role == 'patient' and appointment.patient_id != current_user.id:
        flash('No tienes permiso para ver esta cita.', 'danger')
        return redirect(url_for('dashboard'))
    
    if current_user.role == 'doctor' and appointment.doctor_id != current_user.id:
        flash('No tienes permiso para ver esta cita.', 'danger')
        return redirect(url_for('dashboard'))
    
    return render_template('appointment_confirmation.html', appointment=appointment)

@app.route('/appointments')
@login_required
def appointments():
    if current_user.role == 'patient':
        appointments_list = Appointment.query.filter_by(patient_id=current_user.id).all()
    elif current_user.role == 'doctor':
        appointments_list = Appointment.query.filter_by(doctor_id=current_user.id).all()
    elif current_user.role == 'admin':
        appointments_list = Appointment.query.all()
    else:
        appointments_list = []
    
    now = datetime.now()
    return render_template('appointments.html', appointments=appointments_list, now=now)

@app.route('/appointments/<appointment_id>/cancel', methods=['POST'])
@login_required
def cancel_appointment(appointment_id):
    appointment = Appointment.query.get(appointment_id)
    if not appointment:
        flash('Cita no encontrada.', 'danger')
        return redirect(url_for('appointments'))
    
    # Check if user is allowed to cancel this appointment
    if current_user.role == 'patient' and appointment.patient_id != current_user.id:
        flash('No tienes permiso para cancelar esta cita.', 'danger')
        return redirect(url_for('appointments'))
    
    if current_user.role == 'doctor' and appointment.doctor_id != current_user.id:
        flash('No tienes permiso para cancelar esta cita.', 'danger')
        return redirect(url_for('appointments'))
    
    # Marcar como cancelada
    appointment.status = 'canceled'
    
    # Restaurar el slot como disponible
    new_slot = AvailableSlot(
        doctor_id=appointment.doctor_id,
        slot_datetime=appointment.datetime
    )
    db.session.add(new_slot)
    db.session.commit()
    
    flash('Cita cancelada correctamente.', 'success')
    return redirect(url_for('appointments'))

@app.route('/appointments/<appointment_id>/complete', methods=['POST'])
@login_required
def complete_appointment(appointment_id):
    if current_user.role != 'doctor':
        flash('Solo los médicos pueden marcar citas como completadas.', 'danger')
        return redirect(url_for('appointments'))
    
    appointment = Appointment.query.get(appointment_id)
    if not appointment:
        flash('Cita no encontrada.', 'danger')
        return redirect(url_for('appointments'))
    
    if appointment.doctor_id != current_user.id:
        flash('No tienes permiso para actualizar esta cita.', 'danger')
        return redirect(url_for('appointments'))
    
    appointment.status = 'completed'
    db.session.commit()
    flash('Cita marcada como completada.', 'success')
    return redirect(url_for('appointments'))

@app.route('/api/doctor/<int:doctor_id>/availability', methods=['GET'])
def get_doctor_availability(doctor_id):
    doctor = Doctor.query.get(doctor_id)
    if not doctor:
        return jsonify({'error': 'Doctor not found'}), 404
    
    date_str = request.args.get('date')
    if not date_str:
        return jsonify({'error': 'Date parameter is required'}), 400
    
    try:
        date = datetime.strptime(date_str, '%Y-%m-%d').date()
    except ValueError:
        return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD'}), 400
    
    # Obtener slots disponibles para la fecha especificada
    available_slots_db = AvailableSlot.query.filter_by(doctor_id=doctor_id).all()
    
    # Filtrar por la fecha seleccionada
    available_slots = [
        slot.slot_datetime.strftime('%H:%M') 
        for slot in available_slots_db 
        if slot.slot_datetime.date() == date
    ]
    
    return jsonify({
        'doctor_id': doctor_id,
        'date': date_str,
        'available_slots': available_slots
    })

# Admin routes
@app.route('/admin/doctors', methods=['GET'])
@login_required
def admin_doctors():
    if current_user.role != 'admin':
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('dashboard'))
    
    doctors_list = Doctor.query.all()
    return render_template('admin/doctors.html', doctors=doctors_list)

@app.route('/admin/patients', methods=['GET'])
@login_required
def admin_patients():
    if current_user.role != 'admin':
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('dashboard'))
    
    patients_list = Patient.query.all()
    return render_template('admin/patients.html', patients=patients_list)

@app.route('/admin/appointments', methods=['GET'])
@login_required
def admin_appointments():
    if current_user.role != 'admin':
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('dashboard'))
    
    appointments_list = Appointment.query.all()
    return render_template('admin/appointments.html', appointments=appointments_list)
