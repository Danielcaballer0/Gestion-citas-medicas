from datetime import datetime
import logging

def format_date(date_obj):
    """Format a date object to a readable string"""
    if not date_obj:
        return ""
    return date_obj.strftime("%B %d, %Y")

def format_time(datetime_obj):
    """Format a datetime object to show only time in a readable format"""
    if not datetime_obj:
        return ""
    return datetime_obj.strftime("%I:%M %p")

def format_datetime(datetime_obj):
    """Format a datetime object to a readable string with date and time"""
    if not datetime_obj:
        return ""
    return datetime_obj.strftime("%B %d, %Y at %I:%M %p")

def send_appointment_notification(appointment):
    """
    Send notification for appointment scheduling/changes
    In a real app, this would send emails or SMS
    For this implementation, we'll just log the notification
    """
    from models import Patient, Doctor
    
    patient = Patient.patients.get(appointment.patient_id)
    doctor = Doctor.doctors.get(appointment.doctor_id)
    
    if not patient or not doctor:
        logging.error(f"Failed to send notification: patient or doctor not found for appointment {appointment.id}")
        return False
    
    message = f"""
    Appointment Confirmation
    
    Dear {patient.name},
    
    Your appointment with Dr. {doctor.name} has been scheduled for {format_datetime(appointment.datetime)}.
    
    Please arrive 15 minutes before your scheduled time.
    
    Thank you for choosing our medical services.
    """
    
    # Log the notification (in a real app, this would send an email)
    logging.info(f"Notification sent to {patient.email}: {message}")
    
    # Doctor notification
    doctor_message = f"""
    New Appointment
    
    Dear Dr. {doctor.name},
    
    A new appointment has been scheduled with {patient.name} for {format_datetime(appointment.datetime)}.
    
    Patient contact: {patient.phone}
    """
    
    logging.info(f"Notification sent to {doctor.email}: {doctor_message}")
    
    return True
